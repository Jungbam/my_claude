import React from "react";

export function Hero({ title, subtitle }) {
  return (
    <section className="hero">
      <h1 className="hero-title">{title}</h1>
      <p className="hero-subtitle">{subtitle}</p>
    </section>
  );
}

export function Card({ heading, body }) {
  return (
    <div className="card">
      <h3 className="card-heading">{heading}</h3>
      <p className="card-body">{body}</p>
    </div>
  );
}

export function Footer({ year, brand }) {
  return (
    <footer className="footer">
      <span className="footer-text">
        {brand} © {year}
      </span>
    </footer>
  );
}

export default function SampleGuidePage() {
  return (
    <main className="page">
      <Hero title="Sample Guide" subtitle="Dogfooding fixture for E5" />
      <Card heading="Widget One" body="Placeholder card content." />
      <Footer year={2026} brand="SampleCo" />
    </main>
  );
}
